<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
       <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
       <title><?php echo $title; ?></title>
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet.css" media="all" />
        <link rel="icon" type="image/png" href="Images/olive_icon.jpg" sizes="32x32" />
    </head>
    
    <body>
        <div class="bgded overlay" style="background-image:url('Images/lovcafe-bg1.jpg');">
        <div id="wrapper">
            <div id="banner">             
            </div>
            
            <nav id="navigation">
                <ul id="nav">
                    <li><a href="Index.php">Home</a></li>
                    <li><a href="Dish.php">Dishes</a></li>
                    <li><a href="#">Contact Us</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="Management.php">Management</a></li>
                </ul>
            </nav>
            
            <div id="content_area">
                <?php echo $content; ?>
            </div>
            
            
            
            <footer>
                <p>All Rights Reserved By LovCafe</p>
            </footer>
        </div>
    </body>
</html>