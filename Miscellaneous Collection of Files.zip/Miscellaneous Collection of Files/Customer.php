<?php
require 'Controller/CustomerController.php';
$customerController = new CustomerController();
if(isset($_POST['types']))
{
    //Fill page with dishes of the selected type
    $customerTables = $customerController->CreateCustomerTables($_POST['types']);
}
else 
{
    //When webpage is loaded for the first time, & so no type is selected -> Fetch all types
    $customerTables = $customerController->CreateCustomerTables('%');
}
//Outputing data of webpage
$title = 'Overview of the Customers';
$content = $customerController->CreateCustomerDropdownList(). $customerTables;
include 'Template.php';
?>