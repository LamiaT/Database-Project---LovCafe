<?php
$title = "Managing Employees";
include './Controller/EmployeeController.php';
$employeeController = new EmployeeController();
$content = $employeeController->CreateOverviewTable();
if(isset($_GET["delete"]))
{
    $employeeController->DeleteEmployee($_GET["delete"]);
}
        
include './Template.php';      
?>