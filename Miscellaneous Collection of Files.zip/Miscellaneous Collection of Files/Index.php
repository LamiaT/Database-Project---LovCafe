<?php
$title = "Home | LovCafe";
$content = '
        <img src="Images/carbonara.jpg" class="imgLeft" />
        <h3>Carbonara</h3>
        <p>
             Spaghetti, Fettuccine, Rigatoni, Linguine or, Bucatini Tossed With Beef Pancetta, Olive Oil & Pepper, Served In A Creamy Sauce Of Egg and Parmesan Cheese. 
        </p>
        <img src="Images/spaghetti al pomodoro.jpg" class="imgRight" />
        <h3>Spaghetti Al Pomodoro</h3>
        <p>
            Light tomato pasta dish filled with fresh basil, garlic and Parmesan cheese. Classically prepared with pasta, olive oil, fresh tomatoes, basil, and various other fresh ingredients.
         </p>
         <img src="Images/risotto.jpg" class="imgLeft" />
         <h3>Risotto</h3>
         <p>
            Soft, creamy mound of delicious Italian rice dish with butter, Parmesan cheese, and fresh parsley. Its an all-time Italian classic.
         </p>';
include 'Template.php';
?>