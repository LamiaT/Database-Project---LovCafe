<?php
$title = "Managing Customers";
include './Controller/CustomerController.php';
$customerController = new CustomerController();
$content = $customerController->CreateOverviewTable();
if(isset($_GET["delete"]))
{
    $customerController->DeleteCustomer($_GET["delete"]);
}
        
include './Template.php';      
?>