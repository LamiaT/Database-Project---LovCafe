<?php
$title = "Management";
$content = '<h3>Dishes</h3>
            <a href="DishAdd.php">Add A New Dish</a><br/>
            <a href="UploadImage.php">Upload Image</a><br/>
            <a href="DishOverview.php">Overview of Dish</a><br/>
            <a href="EmployeeOverview.php">Overview of Employees</a><br/>
            <a href="CustomerOverview.php">Overview of Customers</a><br/>';
include './Template.php';
?>