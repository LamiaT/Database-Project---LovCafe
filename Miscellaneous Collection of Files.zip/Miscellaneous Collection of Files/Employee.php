<?php
require 'Controller/EmployeeController.php';
$employeeController = new EmployeeController();
if(isset($_POST['types']))
{
    //Fill page with dishes of the selected type
    $employeeTables = $employeeController->CreateEmployeeTables($_POST['types']);
}
else 
{
    //When webpage is loaded for the first time, & so no type is selected -> Fetch all types
    $employeeTables = $employeeController->CreateEmployeeTables('%');
}
//Outputing data of webpage
$title = 'Overview of the Customers';
$content = $employeeController->CreateEmployeeDropdownList(). $employeeTables;
include 'Template.php';
?>