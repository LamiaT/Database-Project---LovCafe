<?php
class InvoiceEntity
{
    public $dish_id;
    public $order_id;
    public $quantity;
    
    function __construct($did, $oid, $quantity) {
        $this->dish_id = $did;
        $this->order_id = $oid;
        $this->quantity = $quantity;
    }
}
?>