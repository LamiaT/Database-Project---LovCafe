<?php
class CustomerEntity
{
    public $customer_id;
    public $firstName;
    public $middleName;
    public $lastName;
    public $phone;
    public $email;
    public $house;
    public $street;
    public $area;
    public $city;
    public $joinDate;
    public $customer_password;
    
    function __construct($id, $fname, $mname, $lname, $phone, $email, $house, $street, $area, $city, $joindate, $password) {
        $this->customer_id = $id;
        $this->firstName = $fname;
        $this->middleName = $mname;
        $this->lastName = $lname;
        $this->phone = $phone;
        $this->email = $email;
        $this->house = $house;
        $this->street = $street;
        $this->area = $area;
        $this->city = $city;
        $this->joinDate = $joindate;
        $this->customer_password = $password;
    }
}
?>