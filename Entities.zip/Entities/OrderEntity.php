<?php
class OrderEntity
{
    public $order_id;
    public $customer_id;
    public $employee_id;
    
    function __construct($oid, $cid, $eid) {
        $this->order_id = $oid;
        $this->customer_id = $cid;
        $this->employee_id = $eid;
    }
}
?>